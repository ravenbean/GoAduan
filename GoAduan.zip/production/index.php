<?php

	header('Location: aduan.php');

?>