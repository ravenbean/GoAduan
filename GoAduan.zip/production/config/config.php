<?php
	function connect(){
		return mysqli_connect("localhost","goaduanc_super","goaduan123","goaduanc_goaduandb");
	}
?>